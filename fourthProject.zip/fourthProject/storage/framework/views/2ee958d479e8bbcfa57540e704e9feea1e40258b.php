<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Product</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a href="" class="navbar-brand">LOGO</a>
        <ul class="navbar-nav ml-auto">
            <li><a href="" class="nav-link">Add product</a></li>
            <li><a href="" class="nav-link">Jave Script</a></li>
        </ul>
    </div>
</nav>





































<script src="<?php echo e(asset('/assets/js/jquery-3.6.0.min.js')); ?>}"></script>
<script src="<?php echo e(asset('/assets/js/bootstrap.bundle.js')); ?>}"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\fourthProject\resources\views/product/add.blade.php ENDPATH**/ ?>