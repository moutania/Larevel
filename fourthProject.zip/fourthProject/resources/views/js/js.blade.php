@extends('master')
@section('title')
    Java Script

@endsection

@section('body')
    <h1 id="h1"></h1>
    <div id="content"></div>

    <script>
        function createDiv(height,width,color) {
        var  div = document.createElement('div');
        div.style.height = height+'px';
        div.style.width = width+'px';
        div.style.backgroundColor = color;
        div.style.float = 'right';
        div.style.borderRadius = '50%';
        div.setAttribute('id', colorDiv);


         // console.log(div);
         var content = document.getElementsById('content');
         content.append(div);
        }
        createDiv(400,300,'red');
        createDiv(200,100,'green');
        createDiv(300,400,'gray');
        createDiv(500,300,'black');



        // var firstNAme = 'sawon';
        // var lastNAme = 'akter';

        // function printName() {
        //     document.write(firstName + ' ' +lastNAme)
        //
        // }
        // printName();
        // getResult(10,2);

        // function getResult(firstNumber,lastNumber) {
        //     document.write(firstNumber-lastNumber+ '<br>');
        // }
        // getResult(100,50);
        // getResult(500,50);
        // getResult(100,50);
        // getResult(400,50);
        // getResult(100,50);
        //

        function getFullName(firstNAme,lastNAme) {
            // document.write(firstName + ' ' +lastNAme);
            var fullName = firstName + ' ' +lastNAme;
            // var h1 = document.getElementsById('h1');
            // h1.innerHTML = 'fullname';
            document.getElementsByTagName('h1')[0].innerHTML = fullName;// tag
            document.getElementsById('h1').innerHTML = fullName; //


        }
        getFullName("Havibir Rahman")

     // function name() {
     //     // document.write('tarek')
     //     alert('hello world')
     // }

     // name();


        // var data = ['shila','sadia',false, 100,10.25,'bitm', true,'bangladsh', 200,25.30];


        // document.write(data[7]);
        // document.write(data.length);

{{--
        for(key in data)
        {
            if(key>1)
            {
                document.write(key+'<br>');
            }

            // document.write(data[index]+ '<br>');
        }

 --}}

        {{--
        var firstName ='Sanjida';
        var lastName ='Akter';

        Document.write(firstName+' $nbsp '+lastName);



        var Bangladesh = 'Hello BAngladesh';
        var arif_name = 'His Name is arif';
        var hellojenifer = 'her Name is jenifer';
        var crSudipto = 'hello sudipto';

        var firstNumber =10;
        var bitm ='bitm';
        var price ='100.00';

        Document.write(typeof(price));

        --}}


    </script>

@endsection



html:5


{{--

NOTE


 basic rules for variable
 * start with var,
 * a-z,A-Z, 0-9, $,
 *No Number in First

  function-
  * a block of code
  * spacific work
  *reusable
  *nije nije kaj korte parena - execute korte hoi
  *
   execute korar jonno 2 ta part proyojon hoi --1. definition 2.call


 arrea,function,syntex,variable,operator


 --}}
