<h1>login page</h1>
<?php /**PATH C:\xampp\htdocs\mouAuthg_day_36\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>