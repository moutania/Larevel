@extends('master')

@section('title')

    Java script

@endsection


@section('body')

     <h1 id="h1"></h1>
     <div id="content"></div>

    <script>
        function createDiv( height,width,color) {
            var div = document.createElement('div');
            div.style.height = height+'px';
            div.style.width =  width+'px';
            div.style.backgroundColor = color;
            // div.style.backgroundColor = ' red';
            // div.style.marginLeft = ' 10px';
            div.style.float = 'left';
            // div.style.float = 'left';
            div.setAttribute('id', 'colorDiv');


            console.log(div);
            var content = document.getElementById('content');
            content.append(div);

        }
        createDiv(300,400,'red');
        createDiv(200,100,'green');
        createDiv(300,150,'yellow');
        createDiv(500,300,'blue');




// var firstName = 'shaown';
// var lastName = 'AKTER';
// function printName() {
//     document.write(firstName+' '+lastName);
//
// }
//
//
// getResult(10,2);
// function getResult(firstNumber,lastNumber) {
//     document.write(firstNumber-lastNumber+'<br>');
//
// }
// getResult(100,25);
// getResult(101,25);
// getResult(1022,25);

// function getFullName(firstName,lastName) {
//     var fullName = firstName+' '+lastName;
//     var h1Element = document.getElementById('h1');
//     h1Element.innerHTML = fullName;
//     // document.write(firstName+' '+lastName);
//
//
//
// }
// getFullName("Habibur",'rahaman');
//


// printName();

        // // function work
        // name();
        // function name() {
        //     document.write('shaown');
        //
        // }


    </script>

@endsection



