<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index()
    {
        return view('product.add');
    }

    public function newProduct (Request $request)
    {



        Product::SaveData($request);
        return redirect()->back()->with('message', 'Product created successfully.');
    }

    public function manageProduct()
    {
//        return Product::all();
        return view('product.manage',[
            'products' => Product::all(),
        ]);
    }
    public function deleteProduct($id)
    {
       $product = Product::findOrFail($id);
       if (file_exists($product->product_image))
       {
           unlink($product->product_image);
       }
       $product->delete();
       return redirect()->back()->with('message', 'product deleted successfully');
    }
    public function js()
    {
        return view('js.js');
    }

    public function calculator()
    {
        return view('calculator');
    }
}
