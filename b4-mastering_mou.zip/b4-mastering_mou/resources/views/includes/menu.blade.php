


<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
    <div class="container ">
        <a href=""  class="navbar-brand">Logo</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="-menu" >
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapsenavbar-collapse" id="menu">
            <ul class="navbar-nav max-auto">
                <li class="navbar-icon"><a href="{{ route('home') }}" class="nav-link">Home</a></li>
                <li class="navbar-icon"><a href="{{url('/full-name')}}" class="nav-link">Full Name</a></li>
                <li class="navbar-icon"><a href="{{ route('calculator') }}" class="nav-link">Calculator</a></li>
            </ul>
        </div>
    </div>
</nav>
