@extends('master')
@section('title')
    Calculator
@endsection
@section('body')
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <form action="{{ ('get-full-name')}}" method="post">
                    @csrf
                    <div class="form-group row">
                        <label for="" class="col-md-4 col-form-label">First Number</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-md-4 col-form-label">Last Number</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-md-4 col-form-label">Option</label>
                        <div class="col-md-8">
                            <label type="radio"  value="" name="option" value="+">Add</label>
                            <label type="radio"  name="option" value="+">Sub</label>
                            <label type="radio"  name="option" value="*">mul</label>
                            <label type="radio"  name="option" value="/">div</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-md-4 col-form-label">Result</label>
                        <div class="col-md-8">
                            <input type="text" class="form-control" value="{{isset($fullName ) ? $fullName :'' }}" />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-md-4 col-form-label"></label>
                        <div class="col-md-8">
                            <input type="submit" class="btn btn-success btn-block" value="Get Result    ">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

@endsection




{{-- 1. route -use korbo more security er jonno
     2.url -
     3.full-path
    hack er maddhom --- 1. url dhore, 2. form-submit, 3.
--}}
