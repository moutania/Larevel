<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header">Add Product</div>
                    <div class="card-body">
                        <form action="" method="post">
                            <div class="form-group row">
                                <label class="col-md-3">product Name</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="name">

                                </div>

                            </div>
                            <div class="form-group row">
                                <label class="col-md-3">product price</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" name="name">

                                </div>

                            </div>
                            <div class="form-group row">
                                <label class="col-md-3 col-form-label"></label>
                            </div>


                        </form>
                    </div>

                </div>

            </div>

        </div>

    </div>

</section>


<script src="{{asset ('/assets/js/jquery-3.6.0.min.js') }}"></script>
<script src="{{asset ('/assets/js/bootstrap.bundle.js') }}"></script>

</body>
</html>
