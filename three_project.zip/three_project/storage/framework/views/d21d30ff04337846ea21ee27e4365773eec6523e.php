<style>
    .small-image{
        height: 100px !important;
        width: 100px !important;
        cursor: pointer;

    }

</style>

<div class="ml-5" style="height: 400px; width: 600px!importantx;" >
    <img src="<?php echo e(asset('assets/img/11.jpg')); ?>" alt="" id="mainImage" class="img-fluid h-100 ">
</div>
<div class="ml-5 mt-2">
    <img src="<?php echo e(asset('assets/img/11.jpg')); ?>" alt="" onclick="changeImg(11)" class="small-image mr-2" id="smallImage1">
    <img src="<?php echo e(asset('assets/img/22.jpg')); ?>" alt="" onclick="changeImg(22)" class="small-image mr-2" id="smallImage2">
    <img src="<?php echo e(asset('assets/img/33.jpg')); ?>" alt="" onclick="changeImg(33)" class="small-image mr-2" id="smallImage3">
    <img src="<?php echo e(asset('assets/img/44.jpg')); ?>" alt="" onclick="changeImg(44)" class="small-image mr-2" id="smallImage4">
</div>

    <script>
    // var small_image1 = document.getElementById('smallImage1');
    // small_image1.onclick =  function () {
    //     event.preventDefault();
    //     var image_change = document.getElementById('imageChange');
    //     image_change.style.backgroundImage = url("assets/img/11.jpg");
    //
    // }

 // function changeImg(filePath) {
 //
 // }
        var mainImage = document.getElementById('mainImage');
        var smallImage1 = document.getElementById('smallImage1');
     smallImage1.onclick = function () {
         var imgUrl = smallImage1.getAttribute('src');
         mainImage.setAttribute('src',imgUrl);
     }

        var smallImage2 = document.getElementById('smallImage2');
     smallImage2.onclick = function () {
         var imgUrl = smallImage2.getAttribute('src');
         mainImage.setAttribute('src',imgUrl);
     }

          var smallImage3 = document.getElementById('smallImage3');
     smallImage3.onclick = function () {
         var imgUrl = smallImage3.getAttribute('src');
         mainImage.setAttribute('src',imgUrl);
     }

     var smallImage4 = document.getElementById('smallImage4');
     smallImage4.onclick = function () {
         var imgUrl = smallImage4.getAttribute('src');
         mainImage.setAttribute('src',imgUrl);
     }



    </script>


<?php /**PATH C:\xampp\htdocs\three_project\resources\views/includes/imageChange.blade.php ENDPATH**/ ?>