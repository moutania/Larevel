
<div id="xyz" class="">

    <h1 id="headingTag" class="text-center">hello world</h1>

</div>

<div class="py-5">

    <ul class="nav">
        <li class="nav-item">
            <a href="" id="colorRed" class="btn btn-danger nav-link  mr-2">Red</a>
        </li>
        <li class="nav-item">
            <a href="" id="colorGreen" class="btn btn-success nav-link mr-2">Green</a>
        </li>
        <li class="nav-item">
            <a href="" id="colorGray" class="btn btn-secondary nav-link mr-2">Gray</a>
        </li>
        <li class="nav-item">
            <a href="" id="colorBlack" class="btn btn-dark nav-link mr-2">Black</a>
        </li>





    </ul>
    <div id="box" style="height: 300px; width: 300px; border: 1px solid orange " class="mt-3">

    </div>
</div>

<script>
    var btnRed = document.getElementById('colorRed');
    btnRed.onclick = function () {
    event.preventDefault();
    var box = document.getElementById('box');
    box.style.backgroundColor = 'red';

    }
    var btnGreen = document.getElementById('colorGreen');
    btnGreen.onclick = function () {
    event.preventDefault();
    var box = document.getElementById('box');
    box.style.backgroundColor = 'Green';

    }
 var btnGray = document.getElementById('colorGray');
    btnGray.onclick = function () {
    event.preventDefault();
    var box = document.getElementById('box');
    box.style.backgroundColor = 'Gray';

    }
 var btnBlack = document.getElementById('colorBlack');
    btnBlack.onclick = function () {
    event.preventDefault();
    var box = document.getElementById('box');
    box.style.backgroundColor = 'Black';

    }

</script>



<script>
    var heading = document.getElementById('headingTag');
    var xyz = document.getElementById('xyz')
    heading.onclick = function () {
       // heading.innerText = 'Hello BITM';
       heading.innerHTML = 'Hello BITM';
        heading.style.color = 'green';

    }
    heading.onmouseover = function () {
        heading.style.color = 'red';

    }
    heading.onmouseleave = function () {
        heading.style.color = 'black';

    }
    var btn = document.getElementById('color`');


</script>
<?php /**PATH C:\xampp\htdocs\three_project\resources\views/includes/mou.blade.php ENDPATH**/ ?>