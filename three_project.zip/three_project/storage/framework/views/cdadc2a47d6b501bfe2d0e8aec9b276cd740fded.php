<?php $__env->startSection('title'); ?>

    Java script

<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <?php echo $__env->make('includes.mou', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.imageChange', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

     <h1 id="h1"></h1>
     <div id="content"></div>

     <script>
         var name = 'jenifer'; //single
         document.write(name+' ');

         var data = [10,20,30]; //array
         for(key in data)
         {
             document.write(data[2]+ '<br>');
         }

         // var location = {country:'bd', city: 'dhaka', area:'k.b'}
         // var student = {name: 'santo', phone:'0164141355', email: 'santo@gmail.com'};
         //
         // var jenifar = {name: 'pranto', phone:'0164141355', email: 'santo@gmail.com'};

         var students = [
             {name: 'Santo', phone:'0164141355', email: 'santo@gmail.com'},
             {name: 'Arif', phone:'01344141355', email: 'arif@gmail.com'},
             {name: 'Sudipto', phone:'354651355', email: 'sudiptp@gmail.com'},
             {name: 'Jenifer', phone:'354651355', email: 'jenifer@gmail.com'},
             {name: 'Sawon', phone:'654354455', email: 'sawon@gmail.com'},
             {name: 'Sazzad', phone:'054656455', email: 'sazzad@gmail.com'},
         ];

             // document.write(students[4].name);
        for (index in students)
        {
            document.write(`Student name: ${students[index].name} student phone: ${students[index].phone} student Email: ${students[index].email}`+'<br>');
        }

     </script>

<?php $__env->stopSection(); ?>







<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\three_project\resources\views/js/js.blade.php ENDPATH**/ ?>