<?php $__env->startSection('title'); ?>
    Calculator
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto">
                    <div class="card">
                        <div class="card-header">
                            <h2 class="font-weight-bold text-center">Calculator</h2>
                        </div>
                        <div class="card-body bg">
                            <form action="<?php echo e(route('get-calculator-result')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">First Number</label>
                                    <div class="col-md-8">
                                        <input type="number" name="first_number" class="form-control" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Last Number</label>
                                    <div class="col-md-8">
                                        <input type="number" name="last_number" class="form-control" />
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Options</label>
                                    <div class="col-md-8">
                                        <label for=""><input type="radio" name="option" value="+"> add </label>
                                        <label for=""><input type="radio" name="option" value="-"> sub </label>
                                        <label for=""><input type="radio" name="option" value="*"> mul </label>
                                        <label for=""><input type="radio" name="option" value="/"> div </label>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label">Result</label>
                                    <div class="col-md-8">
                                        <input type="text" class="form-control" value="<?php echo e(Session::has('result') ? Session::get('result') : ''); ?>" />
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="" class="col-md-4 col-form-label"></label>
                                    <div class="col-md-8">
                                        <input type="submit" class="btn btn-success btn-block" value="Get Result" />
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b4-mastering_mou\resources\views/calculator/calculator.blade.php ENDPATH**/ ?>