@extends('master')

    @section('title')
        Home
    @endsection

@section('body')
    <h2 class="text-center text-success font-weight-bold">Hello BITM</h2>

@endsection
