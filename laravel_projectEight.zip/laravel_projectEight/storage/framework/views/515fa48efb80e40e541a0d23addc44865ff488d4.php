
<h1>
    <?php echo $firstName; ?>
    <?php echo e($lastName); ?>

</h1>

<?php /**PATH C:\xampp\htdocs\second_project\resources\views/full-name.blade.php ENDPATH**/ ?>