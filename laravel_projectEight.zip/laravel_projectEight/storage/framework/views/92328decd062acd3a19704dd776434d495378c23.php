<?php $__env->startSection('title'); ?>
    Calculator
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card card-body">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">First Number</label>
                            <div class="col-md-8">
                                <input type="number" name="first_number" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Last Number</label>
                            <div class="col-md-8">
                                <input type="number" name="last_number" class="form-control">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Option</label>
                            <div class="col-md-8">
                                <label for=""><input type="radio" name="option" value="+">Add</label>
                                <label for=""><input type="radio" name="option" value="-">Sub</label>
                                <label for=""><input type="radio" name="option" value="*">Mul</label>
                                <label for=""><input type="radio" name="option" value="/">Div</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label">Result</label>
                            <div class="col-md-8">
                                <input type="number" class="form-control" value=""/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="" class="col-md-4 col-form-label"></label>
                            <div class="col-md-8">
                                <input type="submit" class="btn btn-outline-success btn-block" value="Submit Result">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\second_project\resources\views/calculator/calculator.blade.php ENDPATH**/ ?>