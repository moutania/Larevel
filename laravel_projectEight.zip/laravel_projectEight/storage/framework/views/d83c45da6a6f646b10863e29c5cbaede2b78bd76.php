<?php $__env->startSection('body'); ?>


    <script>
        // document.write('hello world');

        // major rules for variable

            //start with var
            // a-z, A-Z, 0-9 $
            // no number in first

        var name = 'santo';
        // var 22street = '22 street';
        var bangladesh = 'hello bangladesh';
        var arif_name = 'arif';
        var jenifar = 'hello jenifar';

        document.write(name);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fourthProject\resources\views/js/js.blade.php ENDPATH**/ ?>