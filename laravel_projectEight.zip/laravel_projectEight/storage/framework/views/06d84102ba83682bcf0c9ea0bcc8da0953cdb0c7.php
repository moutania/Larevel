<?php $__env->startSection('title'); ?>
    Java Script
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    
    <?php echo $__env->make('includes.color-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.image-change', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h1 id="h1"></h1>

    <div id="content">

    </div>

    <script>
        // var name = 'jenifar'; // single variable
        // document.write(name+' ');
        //
        // var data = [10,20,30]; // array
        // for(key in data)
        // {
        //     document.write(data[2]+'<br>');
        // }
        //
        // var country = 'bangladesh';


        var student = { name: 'santo' , phone: '078926', email: 'santo@gmail.com'};
        // var jenifar = { name: 'santo' , phone: '078926', email: 'santo@gmail.com'};

        var students = [
            { name: 'santo' , phone: '078926', email: 'santo@gmail.com'},
            { name: 'sayed' , phone: '3456926', email: 'santo2@gmail.com'},
            { name: 'afif' , phone: '53368926', email: 'santo3@gmail.com'},
            { name: 'sazid' , phone: '5558926', email: 'santo4@gmail.com'},
            { name: 'kamal' , phone: '075558926', email: 'santo5@gmail.com'},
            { name: 'jamal' , phone: '213452326', email: 'santo6@gmail.com'},
        ];
        for (index in students)
        {
            document.write('Student Name:' +students[index].name+' &nbsp; &nbsp;&nbsp; ' +'Student Phone:' +students[index].phone+ ' &nbsp; &nbsp;&nbsp; ' +'Student Email:'+students[index].email+ '<br/>');
        }


    </script>

    <script>

        //        var firstname = 'shawon';
        //        var lastName = 'Akter';
        //
        //        function printName() {
        //            document.write(firstname + ' ' +lastName);
        //        }
        //        // printName();
        //
        //        getResult(10,2);
        //        function getResult(firstNumber,lastNumber) {
        //                document.write(firstNumber-lastNumber+'<br>');
        //        }
        //
        //        getResult(100,50);

        function createDiv(height,width,color) {
            var div = document.createElement("div");

            div.style.height = height+'px';
            div.style.width = width+'px';
            div.style.backgroundColor = color;

            console.log(div);
            var content = document.getElementById('content');
            content.append(div);
            div.style.float = "left";
            div.setAttribute("id","colordiv")

        }



        // createDiv(300, 400, 'red');
        // createDiv(200,100,'green');
        // createDiv(300,150,'grey');
        // createDiv(500,300,'black');

        //
        // function getFullName(firstName,lastName) {
        //    var fullName =  firstName + ' ' +lastName;
        //    var h1Element = document.getElementById("h1");
        //
        //     h1Element.innerHTML = fullName;
        //
        //
        //
        // }
        //
        // getFullName('habibur','rahaman');


        // function name() {
        //     // document.write('hello');
        //     alert('hello world');
        // }
        //
        // name();

        // var data = ['shila', 'sadia',false , 100, 10.25, 'bitm',true, 'bangladesh',100, 25.50];
        //
        // document.write(data[75]);
        //
        //
        // document.write(data.length);
        //
        //
        // for(key in data)
        // {
        //     // if(data[key] == 'bangladesh')
        //     // {
        //     //     document.write(index);
        //     // }
        //     // if (key>1)
        //     // {
        //     //     document.write(data[key]+'<br/>');
        //     // }
        //     // document.write(data[index]+'<br/>');
        //     // document.write(index+'<br/>');
        // }



        // var firstName = 'sanjida';
        // var lastname = 'Akther';
        //
        // document.write(firstName+' &nbsp &nbsp'+lastname);


        // document.write('hello world');

        // major rules for variable

        //start with var
        // a-z, A-Z, 0-9 $
        // no number in first

        // var name = 'santo';
        // var street = '22 street';
        // var bangladesh = 'hello bangladesh';
        // var arif_name = 'arif';
        // var jenifar = 'hello jenifar';

        // document.write(name);

        // var firstNumber = '10';
        // var bitm = 'bitm'
        // var price = 100.00;
        //
        // document.write('bitm');

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sevenproject\resources\views/js/js.blade.php ENDPATH**/ ?>