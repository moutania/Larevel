<?php $__env->startSection('body'); ?>

<script>

    function name()
    {
        // document.write('tarek');
        alert('hello');
    }
    name();



//        var data = [
//          'shila','sadia',false,100,10.25,'bitm',true,'bangladesh',  200, 25.30];
        // document.write(data.length);
        //
        // for (key in data)
        // {
        //     if(data[key] == 'bangladesh')
        //     {
        //         document.write(data[key]+'<be/>');
        //     }
        //     // if(key > 1)
        //     // {
        //     //     document.write(data[key]+'<be/>');
        //     // }

            // document.write(data[key]+'<br/>');
            // // document.write([key+'<br/>']);
            // document.write(data[index]+'<br/>');
        // }

        // document.write(data[50]);

        // var firstName = 'sanjida';
        // var lastName = 'akter';
        // document.write(firstName + '  &nbsp;&nbsp'+ lastName);
        // document.write('hello world');

        // major rules for variable

            //start with var
            // a-z, A-Z, 0-9 $
            // no number in first

        // var name = 'santo';
        // var street = '22 street';
        // var bangladesh = 'hello bangladesh';
        // var arif_name = 'arif';
        // var jenifar = 'hello jenifar';
        //
        // document.write(name);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sixproject\fourthProject\resources\views/js/js.blade.php ENDPATH**/ ?>