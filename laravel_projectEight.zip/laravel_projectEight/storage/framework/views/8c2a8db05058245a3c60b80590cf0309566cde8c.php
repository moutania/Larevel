<style>
    .small-image{
        height: 100px;
        width: 100px;
        cursor: pointer;


    }
</style>


<div class="ml-4" style="height: 400px; width: 600px;">
    <img src="<?php echo e(asset('assets/img/nature1.jpg')); ?>" id="mainImage" alt="" class="img-fluid h-100">
</div>
<div class="ml-4 mt-2">
    <img src="<?php echo e(asset('assets/img/nature2.jpg')); ?>" alt="" onclick="changeImg('nature2')" class="small-image mr-2" id="smallImage1"/>
    <img src="<?php echo e(asset('assets/img/nature3.jpg')); ?>" alt="" onclick="changeImg('nature3')" class="small-image mr-2" id="smallImage2"/>
    <img src="<?php echo e(asset('assets/img/nature1.jpg')); ?>" alt="" onclick="changeImg('nature1')" class="small-image mr-2" id="smallImage3"/>
    <img src="<?php echo e(asset('assets/img/nature4.jpg')); ?>" alt="" onclick="changeImg('nature4')" class="small-image mr-2" id="smallImage4"/>
</div>

<script>
    var mainImage = document.getElementById('mainImage');

    // var smallImage1 = document.getElementById('smallImage1');
    // smallImage1.onclick = function (){
    //     var imgUrl = smallImage1.getAttribute('src');
    //     mainImage.setAttribute('src', imgUrl);
    // }
    // var smallImage2 = document.getElementById('smallImage2');
    // smallImage2.onclick = function (){
    //     var imgUrl = smallImage2.getAttribute('src');
    //     mainImage.setAttribute('src', imgUrl);
    // }
    // var smallImage3 = document.getElementById('smallImage3');
    // smallImage3.onclick = function (){
    //     var imgUrl = smallImage3.getAttribute('src');
    //     mainImage.setAttribute('src', imgUrl);
    // }
    // var smallImage4 = document.getElementById('smallImage4');
    // smallImage4.onclick = function (){
    //     var imgUrl = smallImage4.getAttribute('src');
    //     mainImage.setAttribute('src', imgUrl);
    // }

    function changeImg(filePath){
        var div = document.getElementById('mainImage');
        div.setAttribute('src', `assets/img/${filePath}.jpg`);
    }
</script>
<?php /**PATH C:\xampp\htdocs\sevenproject\resources\views/includes/image-change.blade.php ENDPATH**/ ?>