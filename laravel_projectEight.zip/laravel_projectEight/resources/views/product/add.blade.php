<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Product</title>
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.css')}}">
</head>
<body>

<nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <div class="container">
        <a href="" class="navbar-brand">LOGO</a>
        <ul class="navbar-nav ml-auto">
            <li><a href="" class="nav-link">Add product</a></li>
            <li><a href="" class="nav-link">Manage Product</a></li>
            <li><a href="" class="nav-link">Manage Product</a></li>
        </ul>
    </div>
</nav>

<section class="py-5 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header text-center font-weight-bold ">Registration Form </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="form-group row">
                                <label class="col-md-3">First Name</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="firstName">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3">Last Name</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="lastName">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-md-3">Full Name</label>
                                <div class="col-md-9">
                                    <input type="text" class="form-control" id="fullName">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label"></label>
                                <div class="col-md-9">
                                    <input type="button" class="btn btn-outline-success btn-block" onclick="makeFullName()" value="Submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<script>
    function makeFullName() {

       var firstName = document.getElementById('firstName').value;
       var lastName = document.getElementById('lastName').value;
       var fullName = firstName+' '+lastName;
      document.getElementById('fullName').value = fullName;

      document.getElementById('firstName').value = '';
      document.getElementById('lastName').value = '';

    }
</script>

<script src="{{asset('/assets/js/jquery-3.6.0.min.js')}}}"></script>
<script src="{{asset('/assets/js/bootstrap.bundle.js')}}}"></script>
</body>
</html>
