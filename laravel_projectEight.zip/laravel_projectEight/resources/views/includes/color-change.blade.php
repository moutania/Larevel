<div id="xyz">
    <h1 id="headingTag" class="text-center">hello world</h1>
</div>
<div class="py-5">
    <ul class="nav">
            <li class="nav-item"><a href="" id="colorRed" class="btn mr-2  btn-danger nav-link">Red</a></li>
            <li><a href="" id="colorGreen" class="btn mr-2 btn-success nav-link">Green</a></li>
           <li> <a href="" id="colorGray" class="btn mr-2 btn-primary nav-link">Gray</a></li>
            <li><a href="" id="colorBlack" class="btn mr-2 btn-secondary nav-link">Black</a></li>
    </ul>
    <div id="box" class="mt-3" style="height: 300px; width: 300px; border: 1px solid orange"></div>
</div>


<script>
    var btnRed = document.getElementById('colorRed');
    btnRed.onclick = function (){
        event.preventDefault();
        var box = document.getElementById('box');
        box.style.backgroundColor = 'red';
    }
    var btnGreen = document.getElementById('colorGreen');
    btnGreen.onclick = function (){
        event.preventDefault();
        var box = document.getElementById('box');
        box.style.backgroundColor = 'Green';
    }
    var btnGray = document.getElementById('colorGray');
    btnGray.onclick = function (){
        event.preventDefault();
        var box = document.getElementById('box');
        box.style.backgroundColor = 'Gray';
    }
    var btnBlack = document.getElementById('colorBlack');
    btnBlack.onclick = function (){
        event.preventDefault();
        var box = document.getElementById('box');
        box.style.backgroundColor = 'black';
    }
</script>
<script>
    var heading = document.getElementById('headingTag');
    var xyz = document.getElementById('xyz');
    // console.log(heading);
    heading.onclick =function ()
    {
        // alert('hello bitm');
        // heading.innerText ='hello basis';
        heading.innerHTML ='hello bitm';
        heading.style.color='green';
    }
    heading.onmouseover = function (){
        heading.style.color='red';
    }
    heading.onmouseleave = function (){
        heading.style.color='black';
    }
</script>
