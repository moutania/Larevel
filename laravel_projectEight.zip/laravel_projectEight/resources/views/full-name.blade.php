
<h1>
    <?php echo $firstName; ?>
    {{  $lastName }}
</h1>

